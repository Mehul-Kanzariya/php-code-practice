<?php
$conn =mysqli_connect("db","wordpress","wordpress","wordpress");
// if ($conn) {
//     echo "Connected";
// } else {
//     echo "Disconnected";
// }
?>